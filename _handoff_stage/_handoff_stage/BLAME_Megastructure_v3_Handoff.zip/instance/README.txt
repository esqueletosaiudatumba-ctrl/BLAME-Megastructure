BLAME! INFINITE MEGASTRUCTURE - Prism / ElyPrism instance

INSTALL
1. In Prism/ElyPrism: Add Instance > Import > choose this ZIP.
2. Launch. Prism downloads Minecraft 1.12.2 and Forge 14.23.5.2860 itself (needs Java 8; Prism can auto-download it).
3. Singleplayer > BLAME_Infinite_Megastructure.

Everything else is bundled: CubicChunks (MIT) and blamegen, the mod that generates the megastructure.
No scripts, no downloads by the instance, no commands.

You can also create new worlds: Create New World > More World Options > World Type: "BLAME! Megastructure".
The world starts in creative mode with cheats on so you can fly; /gamemode 0 for survival.

STATUS (honest): the mod is verified on a real Forge 1.12.2 dedicated server (world type loads, cubic world created,
spawn area generated without errors). The game client and this instance import have NOT yet been tested.
Shaders are not included (OptiFine + CubicChunks compatibility unverified).
See docs/SHADERS_AND_VIEW_DISTANCE.md for view-distance tuning, safe performance mods,
manual-thunderstorm shots, and why shaders stay optional.
