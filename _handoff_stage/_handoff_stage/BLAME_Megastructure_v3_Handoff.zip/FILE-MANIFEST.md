# FILE MANIFEST — what changed, what's new, what's untouched

## READ FIRST (in this order)
1. `HANDOFF_BUILD_STATE.md` — where the mod-jar build stopped and how to fix it. **Start here if you want the jar.**
2. `HANDOFF_2026-10-11.md` — the session delta: v1→v3 generator changes, verification, packaging.
3. `HANDOFF.md` — the original project architecture.

## Mod source (`mod/`) — generator version 3
| file | status | note |
|---|---|---|
| `mod/build.gradle` | **NEW (written from scratch)** | the handoff zip had none; see BUILD_STATE |
| `mod/settings.gradle` | modified | plugin-marker group added to GTNH repo filter |
| `mod/gradle.properties` | modified | added version props (unused by RFG 2.x, harmless) |
| `mod/gradle/scripts/dependencies.gradle` | modified | removed 2 unresolvable dev-env runtime deps |
| `.../core/Mat.java` | modified | 14 new materials + 3 new styles |
| `.../core/Cube.java` | modified | `prism`, `tiltSlab`, `archRow`, `blob`, `ring`, `tube` |
| `.../core/Megastructure.java` | modified | ceiling strata, districts, shapeless volumes, doors, viaducts, cranes, tanks, pipes, server vaults, beacons, debris |
| `.../core/Arrival.java` | modified | bigger bay/wall, ocean spires, settlement ruins |
| `.../core/Styles.java` | modified | rust/bio/pipe styles |
| `BlameCubeGenerator.java` | modified | new material → block-state map |
| everything else in `mod/` | unchanged | |

## Tools (new, pure Java, no Minecraft)
- `tools/verify/SeamCheck.java` — containment bands, extreme tiers, spawn
- `tools/verify/Probe.java` — determinism + ceiling wells + block census
- `tools/verify/Survey.java` — coarse-cell parameters + camera coordinates
- `tools/preview/Preview.java` — modified (colours/emissive for new materials)
- `tools/package-instance.ps1` — stages `instance-pkg/` → instance zip
- `tools/make-zip.ps1` — zips with forward-slash entry names (spec-compliant)

## Docs and renders
- `docs/SHADERS_AND_VIEW_DISTANCE.md` — new
- `docs/previews-v2/`, `docs/previews-v3/` — schematic renders (NOT game screenshots)
- `docs/previews-baseline/` — v1 baseline renders, for before/after comparison

## Verification output (`verification-output/`)
- `determinism-and-census.txt` — `determinism: PASS`, ceiling well fraction 0.275, census
- `seam-and-containment.txt` — `SEAMCHECK PASS`
- `coarse-cell-survey.txt` — shaft/void/sea/none + door/rail coordinates
- `bench.txt` — ms per cube

## Instance packaging (`instance-ready-to-package/`)
A complete Prism/ElyPrism import layout **except** `minecraft/mods/blamegen-1.0.0.jar`,
which cannot exist until the mod jar is built (see BUILD_STATE).
Contains: CubicChunks jar (sha1 39045bec72ea7400b91d81c0a14f3d8a685b266d), `instance.cfg`,
`mmc-pack.json`, `blame.png`, `minecraft/options.txt`, `minecraft/config/cubicchunks.cfg`,
`minecraft/saves/BLAME_Infinite_Megastructure/` (no cubes — regenerates fresh as v3),
and a README describing v3. `instance/` holds the same without the CubicChunks jar.

## Deliberately NOT included
- `mod/build/`, `build/`, `~/.gradle` caches — large, regenerable.
- The 5 reference images on the Desktop / `blame_megastructure_ai_inventory.md`
  (outside the project dir) — get them from the user; they drove the design.

## The one thing to remember about the save
`BLAME_Infinite_Megastructure` has no stored cubes, so it regenerates entirely as v3.
Spawn is re-derived at world creation by `WorldEvents` (spawnY = 65).
