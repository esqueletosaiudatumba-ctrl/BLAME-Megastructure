BLAME! INFINITE MEGASTRUCTURE - Prism / ElyPrism instance

INSTALL
1. In ElyPrism/Prism: Add Instance > Import > choose this ZIP.
2. Launch. The launcher downloads Minecraft 1.12.2 and Forge 14.23.5.2860 (needs Java 8;
   the launcher can auto-download it).
3. Singleplayer > BLAME_Infinite_Megastructure.

Everything else is bundled: CubicChunks (MIT) and blamegen, the mod that generates the
megastructure. No scripts, no downloads by the instance, no commands.

You can also create new worlds: Create New World > More World Options > World Type:
"BLAME! Megastructure". The world starts in creative mode with cheats on so you can fly;
/gamemode 0 for survival.

WHAT IS IN THIS BUILD (generator v3)
- A lightless ceiling of dense strata above the roofscape; only sky-open shafts, vents and
  grid-line slots let daylight in. The deep structure is genuinely dark - raise gamma if you
  want to see more.
- Architectural districts: rationalist grids, octagonal stacks, leaning/tilted masses,
  arcaded towns (vaults + colonnades), and organic shapeless accretions of stacked rotated
  prisms with terraces, blobs and pooled water. Whole districts share one character, so the
  world never reads as one repeated module.
- Expanded arrival: a wide beach crescent and bay inside a ~280-radius ring wall, eight
  tapered ocean spires rising from the water, and small human settlement ruins (lockers,
  bunks, terminals, crates, pipe clusters) along the shoreline and at the wall base.
- Passageways: X-orientation transit lines (corner-to-corner tubes, angular rib cages,
  cable-stayed shuttles, tilted slab bridges), elevators/spiral stairwells/lifts on major
  columns, debris fields, fractured decking, ruptured plates.
- Machines and lore objects: colossal doors, blast doors, checkpoint booths, signage strips,
  stairs to nowhere, abandoned rail viaducts with fallen cars, construction cranes, tank
  clusters, district mega-pipes, server vaults, factory halls, ruined defense stations,
  Safeguard beacons with red/amber/green lamps, copper pipework, rust, vents, rebar.
- New materials: warning lamps, glowing conduit/pipe casing, copper patina/raw/weathered,
  rust concrete, biofilm growth (cyan and magenta in deep flooded halls), vents, rebar,
  dark reinforced glass.

STATUS (honest): the pure-Java generator core is verified offline - deterministic output,
containment margins hold, all new materials place, ~0.3 ms per cube. But:
- the mod jar was rebuilt from source for this pack; the Forge mod build itself has not been
  re-run against a live server for v3, and
- the Minecraft client has never been launched with this mod (fog handler, lighting
  propagation through CubicChunks, in-game look, client performance untested).
So expect the possibility of rendering or lighting surprises.

Shaders are NOT included and are NOT recommended: OptiFine 1.12.2 and CubicChunks are known
incompatible upstream, and 1.12.2 shaderpacks load through OptiFine. Weather is locked clear
and noon by design; /weather thunder works manually for storm shots. See
docs/SHADERS_AND_VIEW_DISTANCE.md in the source handoff for view-distance tuning, safe
performance mods (FoamFix, VanillaFix, Phosphor, Surge) and Java flags.

World height comes from cubicchunks.cfg (shipped: effectively unlimited). The bundled save
has no pre-generated cubes, so everything you fly to is generated fresh as v3.
